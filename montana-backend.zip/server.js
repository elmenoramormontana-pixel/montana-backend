const express = require("express");
const jwt = require("jsonwebtoken");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

const SECRET = process.env.SECRET || "montana_secret";

let users = [
  { key: "MONTANA-123", active: true },
  { key: "MONTANA-456", active: false }
];

app.post("/login", (req, res) => {
  const { key } = req.body;

  const user = users.find(u => u.key === key);

  if (!user) return res.status(401).json({ error: "KEY no existe" });
  if (!user.active) return res.status(403).json({ error: "KEY desactivada" });

  const token = jwt.sign({ key }, SECRET, { expiresIn: "1d" });

  res.json({ success: true, token });
});

app.get("/verify", (req, res) => {
  const token = req.headers.authorization;

  if (!token) return res.status(401).json({ valid: false });

  try {
    const decoded = jwt.verify(token, SECRET);
    res.json({ valid: true, user: decoded });
  } catch {
    res.status(401).json({ valid: false });
  }
});

function auth(req, res, next) {
  const token = req.headers.authorization;

  try {
    const decoded = jwt.verify(token, SECRET);
    req.user = decoded;
    next();
  } catch {
    res.status(401).json({ error: "No autorizado" });
  }
}

app.get("/users", auth, (req, res) => {
  res.json(users);
});

app.post("/toggle-user", auth, (req, res) => {
  const { key } = req.body;

  const user = users.find(u => u.key === key);

  if (!user) return res.status(404).json({ error: "Usuario no encontrado" });

  user.active = !user.active;

  res.json({ success: true, active: user.active });
});

app.post("/create-key", auth, (req, res) => {
  const newKey = "MONTANA-" + Math.floor(Math.random() * 1000000);

  users.push({ key: newKey, active: true });

  res.json({ success: true, key: newKey });
});

app.post("/delete-user", auth, (req, res) => {
  const { key } = req.body;

  users = users.filter(u => u.key !== key);

  res.json({ success: true });
});

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log("🔥 Montana backend corriendo en puerto " + PORT);
});
